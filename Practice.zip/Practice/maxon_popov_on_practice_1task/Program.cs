﻿namespace maxon_popov_on_practice_1task
{
    internal class Program
    {
        static void menu()
        {
            Console.WriteLine("Press any button to back menu.");
            Console.ReadLine();
            Console.Clear();
        }
        static void task1()
        {
            try
            {
                double a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter 1 num");

                Console.WriteLine("enter 2 num");
                double b = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter 3 num");
                double c = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter 4 num");
                double d = Convert.ToInt32(Console.ReadLine());

                double sredzn = (a + b + c + b) / 4;

                Console.WriteLine(sredzn);
            }
            catch
            {
                Console.WriteLine("Error");
            }
            menu();
        }

        static void task2()
        {
            try
            {
                Console.WriteLine("enter 1 num");
                double q = Convert.ToInt32(Console.ReadLine());


                Console.WriteLine("enter 2 num");
                double w = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("what do u want:");
                Console.WriteLine("1)+");
                Console.WriteLine("2)-");
                Console.WriteLine("3)*");
                Console.WriteLine("4)/");
                Console.WriteLine("5)%");

                string cal = Console.ReadLine();
                if (cal == "1")
                {
                    double sl = q + w;
                    Console.WriteLine(sl);
                }
                else if (cal == "2")
                {
                    double min = q - w;
                    Console.WriteLine(min);

                }
                else if (cal == "3")
                {
                    double umn = q * w;
                    Console.WriteLine(umn);
                }
                else if (cal == "4")
                {
                    double del = q / w;
                    Console.WriteLine(del);
                }
                else if (cal == "5")
                {
                    double proc = q % w;
                    Console.WriteLine(proc);
                }
            }
            catch
            {
                Console.WriteLine("Error");
            }
            menu();
        }

        static void task3()
        {
            try
            {
                Console.WriteLine("Выберите формат:");
                Console.WriteLine("1) Celsius");
                Console.WriteLine("2) Kelvin");
                Console.WriteLine("3) Fahrenheit");
                string firstDT = Console.ReadLine();
                Console.WriteLine("Введите температуру");
                double D = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Выберите формат в который нужно перевести:");
                Console.WriteLine("1) Celsius");
                Console.WriteLine("2) Kelvin");
                Console.WriteLine("3) Fahrenheit");
                string secondDT = Console.ReadLine();
                if (firstDT == secondDT)
                {
                    Console.WriteLine();
                }
                else if (firstDT == "1" && secondDT == "2")
                {
                    Console.WriteLine($" {D} Celsius in Kelvin = {273.15 + D}");

                }
                else if (firstDT == "1" && secondDT == "3")
                {
                    Console.WriteLine($" {D} Celsius in Kelvin = {30 + (2 * D)}");
                }
                else if (firstDT == "2" && secondDT == "1")
                {
                    Console.WriteLine($" {D} Celsius in Kelvin = {-273.15 + D}");

                }
                else if (firstDT == "2" && secondDT == "3")
                {
                    Console.WriteLine($" {D} Celsius in Kelvin = {(D - 273.15) * 9 / 5 + 32}");
                }
                else if (firstDT == "3" && secondDT == "1")
                {
                    Console.WriteLine($" {D} Celsius in Kelvin = {(D - 30) / 2}");

                }
                else if (firstDT == "3" && secondDT == "2")
                {
                    Console.WriteLine($" {D} Celsius in Kelvin = {(D - 32) / 9 / 5 + 273.15}");
                }
            }
            catch
            {
                Console.WriteLine("Error");

            }
            menu();
        }
        static void task4()
        {
            try
            {
                Console.WriteLine("Введите путь");
                string str = Console.ReadLine();
                string[] parts = str.Split('/');
                Console.WriteLine(parts[parts.Length - 1]);
                Console.WriteLine("Нажмите любую клавишу");
                Console.ReadLine();
                Console.Clear();
            }
            catch
            {
                Console.WriteLine("Error");
            }
            menu();
        }
        static void task5()
        {
            try
            {
                Console.WriteLine("Введите ваше предложение");
                string str = Console.ReadLine();
                string[] parts = str.Split(' ');
                string maxlen = "";
                for (int i = 0; i < parts.Length; i++)
                {
                    string currentlen = parts[i];
                    if (maxlen.Length < currentlen.Length)
                    {
                        maxlen = parts[i];
                    }
                }
                Console.WriteLine("Самое длинное слово это " + maxlen);
                Console.WriteLine("Нажмите любую клавишу");
                Console.ReadLine();
                Console.Clear();
            }
            catch
            {
                Console.WriteLine("Error");
            }
            menu();
        }
        static void task6()
        {
            try
            {
                Console.WriteLine("Введите значения для первого массива через пробел:");
                string strr = Console.ReadLine();
                string[] firstArrey = strr.Split(' ');
                Console.WriteLine("Введите значения для второго массива через пробел:");
                strr = Console.ReadLine();
                string[] secondArrey = strr.Split(' ');
                string[] thirdArray;
                for (int i = 0; i < firstArrey.Length; i++)
                {
                    Console.Write($"{Convert.ToInt32(firstArrey[i]) * Convert.ToInt32(secondArrey[i])} ");
                }
                Console.WriteLine("Нажмите любую клавишу");
                Console.ReadLine();
                Console.Clear();
            }
            catch
            {
                Console.WriteLine("Error");
            }
            menu();
        }
        static void task7()
        {
            try
            {
                Console.WriteLine("Введите пять чисел через пробел" +
                    ":");
                string str = Console.ReadLine();
                string[] partse = str.Split(" ");
                int suMax = -999999999;
                int suMin = 999999999;
                foreach (string i in partse)
                {
                    if (suMax < Convert.ToInt32(i))
                    {
                        suMax = Convert.ToInt32(i);
                    }
                    if (suMin > Convert.ToInt32(i))
                    {
                        suMin = Convert.ToInt32(i);
                    }
                }
                Console.WriteLine("Максимальное число: " + suMax); Console.WriteLine("Минимальное число: " + suMin);
                Console.WriteLine("Нажмите любую клавишу");
                Console.ReadLine();
                Console.Clear();
            }
            catch
            {
                Console.WriteLine("Error");
            }
            menu();
        }
        static void task8()
        {
            try
            {
                Console.Write(" Введите уровень пирамиды : ");
                int levels = Convert.ToInt32(Console.ReadLine());

                for (int i = 1; i <= levels; i++)
                {
                    for (int j = 0; j < levels - i; j++)
                    {
                        Console.Write(" ");
                    }
                    for (int k = 1; k <= i; k++)
                    {
                        Console.Write(k + " ");
                    }


                    Console.WriteLine();
                }
                Console.WriteLine("Нажмите любую клавишу");
                Console.ReadLine();
                Console.Clear();
            }
            catch
            {
                Console.WriteLine("Error");
            }
            menu();
        }
        static void task9()
        {
            try
            {
                for (int i = 1; i <= 9; i++)
                {
                    for (int j = 1; j <= 9; j++)
                    {
                        Console.Write($"{1} x {j} = {i * j}\t");
                    }

                    Console.WriteLine();

                }
                Console.WriteLine("Нажмите любую клавишу");
                Console.ReadLine();
                Console.Clear();
            }
            catch
            {
                Console.WriteLine("Error");
            }
            menu();
        }
        static void task16()
        {
            try
            {
                Console.Write("Введите минимальное число (a): ");
                int a = int.Parse(Console.ReadLine());

                Console.Write("Введите максимальное число (b): ");
                int b = int.Parse(Console.ReadLine());

                Console.WriteLine("Выберите действие:");
                Console.WriteLine("1 - Вывод суммы всех целых чисел от a до b");
                Console.WriteLine("2 - Вывод суммы всех целых четных чисел в промежутке от a до b");
                Console.WriteLine("3 - Вывод сумму всех целых нечетных чисел в промежутке от a до b");

                int choice = int.Parse(Console.ReadLine());
                int result = 0;

                switch (choice)
                {
                    case 1:
                        for (int i = a; i <= b; i++)
                        {
                            result += i;
                        }
                        break;
                    case 2:
                        for (int i = a; i <= b; i++)
                        {
                            if (i % 2 == 0)
                            {
                                result += i;
                            }
                        }
                        break;
                    case 3:
                        for (int i = a; i <= b; i++)
                        {
                            if (i % 2 != 0)
                            {
                                result += i;
                            }
                        }
                        break;
                    default:
                        Console.WriteLine("Неправильный выбор");
                        return;
                }

                Console.WriteLine("Результат: " + result);
            }
            catch
            {
                Console.WriteLine("Error");
            }
            menu();
        }
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("press num:");
                Console.WriteLine("task1");
                Console.WriteLine("task2");
                Console.WriteLine("task3");
                Console.WriteLine("task4");
                Console.WriteLine("task5");
                Console.WriteLine("task6");
                Console.WriteLine("task7");
                Console.WriteLine("task8");
                Console.WriteLine("task9");
                Console.WriteLine("task16");
                string choose = Console.ReadLine();

                Console.Clear();
                if (choose == "1")
                {
                    task1();
                }
                else if (choose == "2")
                {
                    task2();
                }
                if (choose == "3")
                {
                    task3();
                }
                if (choose == "4")
                {
                    task4();
                }
                else if (choose == "5")
                {
                    task5();
                }
                if (choose == "6")
                {
                    task6();
                }
                else if (choose == "7")
                {
                    task7();
                }
                if (choose == "8")
                {
                    task8();
                }
                else if (choose == "9")
                {
                    task9();
                }
                if (choose == "16")
                {
                    task16();
                }
                {
                    Console.WriteLine("Error");
                }
            }
        }
    }
}
